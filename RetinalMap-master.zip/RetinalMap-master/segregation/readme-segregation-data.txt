Please note that the ages P21, P22 and P23 have been grouped together and are now labeled as P22.
