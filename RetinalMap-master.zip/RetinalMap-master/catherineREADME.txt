There is now a connectionMatrix variable: One column per RGC, one row per SC

If you use the function obj.synchroniseConnectionTables('mat2pre')
then you will convert from the connectionMatrix representation to the
presynaptic representation I use by default for my code.

